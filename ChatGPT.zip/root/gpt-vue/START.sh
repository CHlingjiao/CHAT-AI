npm i -f && npm run dev
