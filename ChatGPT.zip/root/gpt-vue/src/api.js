export const apiKey = process.env.INSCODE_API_KEY;
export const apiUrl = 'https://inscode-api.csdn.net/api/v1/gpt/';